#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <errno.h>
#include <string.h>

#define SYS_CSCI_ADD 334  //doublecheck the  syscall_64.tbl

int main() {
    int num1 = 10, num2 = 20, result;
    long status;

    // Passing the pointers to syscall
    status = syscall(SYS_CSCI_ADD, &num1, &num2, &result);

    // Checking for errors
    if (status == 0) {
        printf("csci_add: %d + %d = %d\n", num1, num2, result);
    } else {
        printf("csci_add failed with error: %s\n", strerror(errno));
    }

    return 0;
}
