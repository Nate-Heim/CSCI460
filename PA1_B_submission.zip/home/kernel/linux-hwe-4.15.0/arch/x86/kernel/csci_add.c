#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/uaccess.h>  // Needed for copy_from_user() and copy_to_user()

SYSCALL_DEFINE3(csci_add, int __user *, user_num1, int __user *, user_num2, int __user *, user_result) {
    int num1, num2, sum;

    // Copying numbers from user space to kernel space
    if (copy_from_user(&num1, user_num1, sizeof(int)) ||
        copy_from_user(&num2, user_num2, sizeof(int))) {
        return -EFAULT;  // Return error if copy fails
    }

    // Logging values received from user space in kernel
    printk(KERN_ALERT "csci_add: Adding %d and %d\n", num1, num2);

    // Computing the sum
    sum = num1 + num2;

    // Copying the result back to user space here
    if (copy_to_user(user_result, &sum, sizeof(int))) {
        return -EFAULT;  // Return error if copying fails
    }

    // Logging the result into the kernel here
    printk(KERN_ALERT "csci_add: Result = %d\n", sum);

    return 0; // dear god this code drives me crazy...okay maybe I already am a bit but still
}
