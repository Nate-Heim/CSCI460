//Nate Heim
//CSCI 460: Operating Systems
//PA2 Part B

#include <linux/init.h>       // Module initialization and exit
#include <linux/module.h>     // Core header for loading LKMs
#include <linux/fs.h>         // File operations structure
#include <linux/slab.h>       // For kmalloc() and kfree()
#include <linux/uaccess.h>    // For copy_to_user() and copy_from_user()

#define BUFFER_SIZE 1024      // Buffer size of 1KiB

// Device buffer and position tracking
static char *device_buffer;
static size_t data_end = 0;   // Tracks the end of the written data

// Open function
int pa2_char_driver_open(struct inode *pinode, struct file *pfile) {
    static int open_count = 0;
    open_count++;
    printk(KERN_INFO "pa2_char_driver: Device opened %d times.\n", open_count);
    return 0;
}

// Release (Close) function
int pa2_char_driver_close(struct inode *pinode, struct file *pfile) {
    static int close_count = 0;
    close_count++;
    printk(KERN_INFO "pa2_char_driver: Device closed %d times.\n", close_count);
    return 0;
}

// Read function
ssize_t pa2_char_driver_read(struct file *pfile, char __user *buffer, size_t length, loff_t *offset) {
    size_t bytes_to_read;

    // Only print the warning if actually out of bounds not because of it
    if (*offset > data_end) {
        printk(KERN_WARNING "pa2_char_driver: Read out of bounds.\n");
        return 0;  // End of file
    }

    // Return 0 silently if at the end of valid data
    if (*offset == data_end) {
        return 0;  // End of file
    }

    // Only read up to the end of the written data
    bytes_to_read = min(length, (size_t)(data_end - *offset));

    // Copy data from device buffer to user space
    if (copy_to_user(buffer, device_buffer + *offset, bytes_to_read)) {
        printk(KERN_ERR "pa2_char_driver: Failed to read data to user space.\n");
        return -EFAULT; // Bad address
    }

    // Update offset and sync file pointer
    *offset += bytes_to_read;
    pfile->f_pos = *offset;

    printk(KERN_INFO "pa2_char_driver: Read %zu bytes from position %lld.\n", bytes_to_read, *offset);

    return bytes_to_read;
}

// Write function
ssize_t pa2_char_driver_write(struct file *pfile, const char __user *buffer, size_t length, loff_t *offset) {
    size_t bytes_to_write;

    // Prevents writing beyond buffer size
    if (*offset >= BUFFER_SIZE) {
        printk(KERN_WARNING "pa2_char_driver: Write out of bounds.\n");
        return -EFBIG; // File too large
    }

    // Calculate the number of bytes to write
    bytes_to_write = min(length, (size_t)(BUFFER_SIZE - *offset));

    // Copy data from user space to device buffer
    if (copy_from_user(device_buffer + *offset, buffer, bytes_to_write)) {
        printk(KERN_ERR "pa2_char_driver: Failed to write data from user space.\n");
        return -EFAULT; // Bad address
    }

    // Update offset and data_end
    *offset += bytes_to_write;
    data_end = max(data_end, *offset);  // Track end of written data

    // Sync file pointer with new offset
    pfile->f_pos = *offset;

    // Clear remaining buffer to prevent garbage data
    memset(device_buffer + *offset, 0, BUFFER_SIZE - *offset);

    printk(KERN_INFO "pa2_char_driver: Wrote %zu bytes to position %lld.\n", bytes_to_write, *offset);

    return bytes_to_write;
}

// Seek function
loff_t pa2_char_driver_seek(struct file *pfile, loff_t offset, int whence) {
    loff_t new_pos; //whence is still archaic even if it is an actual function...

    switch (whence) {
        case SEEK_SET:
            new_pos = offset;
            break;
        case SEEK_CUR:
            new_pos = pfile->f_pos + offset;
            break;
        case SEEK_END:
            new_pos = data_end + offset;
            break;
        default:
            return -EINVAL;
    }

    // Bounds check
    if (new_pos < 0 || new_pos > BUFFER_SIZE) {
        printk(KERN_WARNING "pa2_char_driver: Seek out of bounds.\n");
        return -EINVAL;
    }

    // Update file pointer
    pfile->f_pos = new_pos;
    printk(KERN_INFO "pa2_char_driver: New file position: %lld.\n", new_pos);

    return new_pos;
}

// File operations structure
struct file_operations pa2_char_driver_file_operations = {
    .owner = THIS_MODULE,
    .open = pa2_char_driver_open,
    .release = pa2_char_driver_close,
    .read = pa2_char_driver_read,
    .write = pa2_char_driver_write,
    .llseek = pa2_char_driver_seek,
};

// Init function
static int pa2_char_driver_init(void) {
    device_buffer = kmalloc(BUFFER_SIZE, GFP_KERNEL);
    if (!device_buffer) {
        printk(KERN_ERR "pa2_char_driver: Failed to allocate memory.\n");
        return -ENOMEM;
    }

    // Zero out the buffer to prevent garbage data
    memset(device_buffer, 0, BUFFER_SIZE);

    register_chrdev(240, "pa2_char_driver", &pa2_char_driver_file_operations);
    printk(KERN_INFO "pa2_char_driver: Initialized successfully.\n");

    return 0;
}

// Exit function
static void pa2_char_driver_exit(void) {
    kfree(device_buffer);
    unregister_chrdev(240, "pa2_char_driver");
    printk(KERN_INFO "pa2_char_driver: Unloaded successfully.\n");
}

module_init(pa2_char_driver_init);
module_exit(pa2_char_driver_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Nate Heim");
MODULE_DESCRIPTION("CSCI 460 - PA2_B Character Device Driver");

