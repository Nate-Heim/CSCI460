#ifndef ARRAY_H
#define ARRAY_H

#include <pthread.h>

#define ARRAY_CAPACITY 10  // Maximum number of elements in the shared array

typedef struct {
    char *storage[ARRAY_CAPACITY];  // Array to store domain names
    int next_insert_index;  // Index for the next insertion position
    int next_remove_index; // Index for the next removal position
    int current_size; // Tracks the number of elements currently in the buffer
    pthread_mutex_t buffer_mutex; // Mutex for synchronizing access to the shared array
    pthread_cond_t buffer_not_empty; // Condition variable to signal consumers when data is available
    pthread_cond_t buffer_not_full;  // Condition variable to signal producers when space is available
} shared_array;

void array_init(shared_array *arr); // Initializes the shared array
void array_insert(shared_array *arr, char *item); // Inserts an item into the shared array
char* array_remove(shared_array *arr); // Removes and returns an item from the shared array
void array_destroy(shared_array *arr); // Frees the shared array's resources

#endif /* ARRAY_H */
