#include "array.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void array_init(shared_array *arr) {
    arr->next_insert_index = 0; // Initialize the index for inserting data
    arr->next_remove_index = 0; // Initialize the index for removing data
    arr->current_size = 0; // Set the initial buffer size to zero
    pthread_mutex_init(&arr->buffer_mutex, NULL); // Initialize the mutex for synchronization
    pthread_cond_init(&arr->buffer_not_empty, NULL); // Initialize condition variable for consumers
    pthread_cond_init(&arr->buffer_not_full, NULL); // Initialize condition variable for producers
}

void array_insert(shared_array *arr, char *item) {
    pthread_mutex_lock(&arr->buffer_mutex); // Lock the mutex before modifying the buffer
    while (arr->current_size == ARRAY_CAPACITY) {  // Wait if the buffer is full
        pthread_cond_wait(&arr->buffer_not_full, &arr->buffer_mutex);
    }
    arr->storage[arr->next_insert_index] = strdup(item); // Copy item into the buffer
    arr->next_insert_index = (arr->next_insert_index + 1) % ARRAY_CAPACITY; // Move to the next index circularly
    arr->current_size++; // Increment the size of the buffer
    pthread_cond_signal(&arr->buffer_not_empty); // Signal that buffer has data available
    pthread_mutex_unlock(&arr->buffer_mutex); // Unlock the mutex after insertion
}

char* array_remove(shared_array *arr) {
    pthread_mutex_lock(&arr->buffer_mutex); // Lock the mutex before modifying the buffer
    while (arr->current_size == 0) {  // Wait if the buffer is empty
        pthread_cond_wait(&arr->buffer_not_empty, &arr->buffer_mutex);
    }
    char *item = arr->storage[arr->next_remove_index]; // Remove item from buffer
    arr->storage[arr->next_remove_index] = NULL; // Clear the reference to prevent dangling pointers
    arr->next_remove_index = (arr->next_remove_index + 1) % ARRAY_CAPACITY; // Move to the next index circularly
    arr->current_size--; // Decrement the size of the buffer
    pthread_cond_signal(&arr->buffer_not_full); // Signal that buffer has space available
    pthread_mutex_unlock(&arr->buffer_mutex); // Unlock the mutex after removal
    return item; // Return the removed item
}

void array_destroy(shared_array *arr) {
    // This should free any remaining allocated memory in the buffer
    for (int i = arr->next_remove_index; arr->current_size > 0; i = (i + 1) % ARRAY_CAPACITY) {
        free(arr->storage[i]); // Free each allocated string
        arr->storage[i] = NULL; // Clear reference to prevent accidental reuse
        arr->current_size--; // Reduce the size counter
    }
    pthread_mutex_destroy(&arr->buffer_mutex); // Destroy the mutex to clean up resources
    pthread_cond_destroy(&arr->buffer_not_empty); // Destroy the not_empty condition variable
    pthread_cond_destroy(&arr->buffer_not_full); // Destroy the not_full condition variable
}
